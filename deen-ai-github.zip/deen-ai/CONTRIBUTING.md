# Contributing to Deen AI 🌙

JazakAllahu Khayran for wanting to contribute! Every contribution is Sadaqah Jariyah. 🤲

## Getting Started

1. Fork the repo
2. Clone your fork: `git clone https://github.com/YOUR_USERNAME/deen-ai.git`
3. Follow Quick Start in README.md
4. Make your changes
5. Submit a Pull Request

## Branch Naming

- `feature/` — New features
- `fix/` — Bug fixes  
- `lang/` — Language additions
- `docs/` — Documentation

## Islamic Content Guidelines

- All Islamic content must be from authentic sources (Quran, Sahih Hadith)
- Never issue definitive fatwas — always guide to scholars
- Be respectful of all madhabs (Hanafi, Shafi'i, Maliki, Hanbali)
- Responses must be kind, non-judgmental, and merciful

## Code Style

- Use meaningful variable names
- Comment complex logic
- Keep components small and focused
- CSS Modules for styling

## Need Help?

Open an issue — we're here to help! 🌙
