// app/api/chat/route.js
// ════════════════════════════════════════
// Deen AI — Secure Chat API Route
// API key stays server-side only
// ════════════════════════════════════════

import { callDeenAI } from '@/lib/openrouter'

export async function POST(request) {
  try {
    const { messages } = await request.json()

    if (!messages || !Array.isArray(messages)) {
      return Response.json(
        { error: 'Invalid request — messages array required' },
        { status: 400 }
      )
    }

    // Keep last 12 messages for context
    const trimmedMessages = messages.slice(-12)

    const result = await callDeenAI(trimmedMessages)

    if (!result.success) {
      return Response.json(
        { error: 'Service temporarily unavailable', details: result.errors },
        { status: 503 }
      )
    }

    return Response.json({
      reply: result.reply,
      model: result.model,
    })

  } catch (err) {
    console.error('Deen AI API error:', err)
    return Response.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
