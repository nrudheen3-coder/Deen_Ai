// app/layout.js
import './globals.css'

export const metadata = {
  title: 'Deen AI — دين | Free Islamic Life Companion',
  description: 'Free Islamic AI guidance in Tamil, English, Urdu, Arabic & Malay. Ask about Quran, Hadith, family, halal business and mental peace.',
  manifest: '/manifest.json',
  themeColor: '#0a2e1a',
  appleWebApp: {
    capable: true,
    statusBarStyle: 'black-translucent',
    title: 'Deen AI',
  },
  openGraph: {
    title: 'Deen AI — Free Islamic Life Companion',
    description: 'Built by Muslims, For Muslims. Free Forever.',
    type: 'website',
  },
}

export const viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  themeColor: '#0a2e1a',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          href="https://fonts.googleapis.com/css2?family=Amiri:ital,wght@0,400;0,700;1,400&family=Tajawal:wght@300;400;500;700&family=Scheherazade+New:wght@400;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  )
}
