// app/page.js
'use client'
import { useState, useEffect } from 'react'
import SplashScreen from '@/components/SplashScreen'
import LanguageScreen from '@/components/LanguageScreen'
import MainApp from '@/components/MainApp'

export default function Home() {
  const [screen, setScreen] = useState('splash') // splash | language | main
  const [language, setLanguage] = useState(null)

  useEffect(() => {
    // Check saved language preference
    const saved = localStorage.getItem('deen-ai-lang')
    if (saved) {
      const lang = JSON.parse(saved)
      setLanguage(lang)
      // Skip to main after splash
      setTimeout(() => setScreen('main'), 2500)
    } else {
      setTimeout(() => setScreen('language'), 2800)
    }
  }, [])

  function handleLanguageSelect(lang) {
    localStorage.setItem('deen-ai-lang', JSON.stringify(lang))
    setLanguage(lang)
    setScreen('main')
  }

  function handleChangeLanguage() {
    setScreen('language')
  }

  return (
    <div style={{
      height: '100dvh',
      maxWidth: '430px',
      margin: '0 auto',
      background: 'var(--green-deep)',
      position: 'relative',
      overflow: 'hidden',
    }}>
      {screen === 'splash' && <SplashScreen />}
      {screen === 'language' && (
        <LanguageScreen onSelect={handleLanguageSelect} />
      )}
      {screen === 'main' && language && (
        <MainApp
          language={language}
          onChangeLanguage={handleChangeLanguage}
        />
      )}
    </div>
  )
}
