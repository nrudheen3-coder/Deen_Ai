// components/SplashScreen.jsx
'use client'
import styles from './SplashScreen.module.css'

export default function SplashScreen() {
  return (
    <div className={styles.splash}>
      <div className={styles.pattern} />
      <div className={styles.glow} />

      <div className={styles.moon}>
        <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <radialGradient id="moonGrad" cx="40%" cy="40%">
              <stop offset="0%" stopColor="#f5cf6b"/>
              <stop offset="100%" stopColor="#c49a1e"/>
            </radialGradient>
          </defs>
          <path
            d="M50 10 C28 10 10 28 10 50 C10 72 28 90 50 90 C35 80 25 66 25 50 C25 34 35 20 50 10Z"
            fill="url(#moonGrad)"
            opacity="0.95"
          />
          <circle cx="62" cy="28" r="6" fill="#f5cf6b" opacity="0.9"/>
          <circle cx="72" cy="42" r="3.5" fill="#e8b923" opacity="0.7"/>
        </svg>
      </div>

      <div className={styles.arabic}>دين</div>
      <div className={styles.title}>DEEN AI</div>
      <div className={styles.tagline}>
        Your Free Islamic Life Companion<br/>
        Tamil • English • Urdu • Arabic • Malay
      </div>

      <div className={styles.dots}>
        <div className={styles.dot} />
        <div className={styles.dot} />
        <div className={styles.dot} />
      </div>
    </div>
  )
}
