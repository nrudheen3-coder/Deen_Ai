// components/ChatTab.jsx
'use client'
import { useState, useRef, useEffect } from 'react'
import styles from './ChatTab.module.css'

const TOPICS = [
  { id: 'all',      icon: '✨', label: 'All Topics'    },
  { id: 'life',     icon: '🌿', label: 'Daily Life'    },
  { id: 'quran',    icon: '📖', label: 'Quran'         },
  { id: 'family',   icon: '👨‍👩‍👧', label: 'Family'       },
  { id: 'business', icon: '💼', label: 'Halal Business'},
  { id: 'mental',   icon: '🤲', label: 'Mental Peace'  },
]

const QUICK_QUESTIONS = [
  '💭 How do I make istikhara for a big decision?',
  '💑 How to strengthen my marriage in Islam?',
  '💼 Is dropshipping halal in Islam?',
  '🧠 I feel anxious — what does Islam say?',
]

export default function ChatTab({ language, initialTopic }) {
  const [messages, setMessages] = useState([])
  const [input, setInput] = useState('')
  const [typing, setTyping] = useState(false)
  const [topic, setTopic] = useState('all')
  const [history, setHistory] = useState([])
  const messagesEndRef = useRef(null)
  const inputRef = useRef(null)
  const isRTL = language?.dir === 'rtl'

  useEffect(() => {
    if (initialTopic) setTopic(initialTopic)
  }, [initialTopic])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, typing])

  async function sendMessage(text) {
    const msg = text || input.trim()
    if (!msg || typing) return

    setInput('')

    const userMsg = { role: 'user', content: msg, time: getTime() }
    setMessages(prev => [...prev, userMsg])

    const newHistory = [...history, { role: 'user', content: msg }]
    setHistory(newHistory)
    setTyping(true)

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: newHistory }),
      })

      const data = await res.json()

      if (data.reply) {
        const aiMsg = { role: 'ai', content: data.reply, time: getTime(), model: data.model }
        setMessages(prev => [...prev, aiMsg])
        setHistory(prev => [...prev, { role: 'assistant', content: data.reply }])
      } else {
        throw new Error('No reply')
      }
    } catch {
      setMessages(prev => [...prev, {
        role: 'ai',
        content: language?.errorMsg || "I'm having trouble connecting. Please try again. 🤲",
        time: getTime(),
      }])
    }

    setTyping(false)
  }

  function handleKey(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  function getTime() {
    return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  }

  const hasMessages = messages.length > 0

  return (
    <div className={styles.chat}>
      {/* Topic Chips */}
      <div className={styles.chips}>
        {TOPICS.map(t => (
          <div
            key={t.id}
            className={`${styles.chip} ${topic === t.id ? styles.chipActive : ''}`}
            onClick={() => setTopic(t.id)}
          >
            <span>{t.icon}</span>
            <span className={styles.chipLabel}>{t.label}</span>
          </div>
        ))}
      </div>

      {/* Messages */}
      <div className={styles.messages}>
        {!hasMessages && (
          <div className={styles.welcome}>
            <span className={styles.welcomeEmoji}>🌙</span>
            <div className={styles.welcomeTitle}>
              {language?.greeting || 'Assalamu Alaikum'}
            </div>
            <div className={styles.welcomeText}>
              I am Deen AI — your free Islamic life companion.<br/>
              Ask me anything about your deen, daily life, family, or business.
            </div>
            <div className={styles.quickList}>
              {QUICK_QUESTIONS.map((q, i) => (
                <div
                  key={i}
                  className={styles.quickQ}
                  onClick={() => sendMessage(q.substring(2).trim())}
                >
                  {q}
                </div>
              ))}
            </div>
          </div>
        )}

        {messages.map((msg, i) => (
          <div
            key={i}
            className={`${styles.msg} ${msg.role === 'user' ? styles.msgUser : styles.msgAi}`}
          >
            {msg.role === 'ai' && (
              <div className={styles.msgHeader}>
                <div className={styles.avatar}>د</div>
                <span className={styles.aiName}>Deen AI</span>
              </div>
            )}
            <div
              className={styles.bubble}
              dir={isRTL ? 'rtl' : 'auto'}
              dangerouslySetInnerHTML={{ __html: formatText(msg.content) }}
            />
            {msg.role === 'ai' && hasQuranRef(msg.content) && (
              <div className={styles.reference}>📖 Quran / Hadith referenced</div>
            )}
            <div className={styles.time}>{msg.time}</div>
          </div>
        ))}

        {typing && (
          <div className={`${styles.msg} ${styles.msgAi}`}>
            <div className={styles.msgHeader}>
              <div className={styles.avatar}>د</div>
              <span className={styles.aiName}>Deen AI</span>
            </div>
            <div className={styles.typingBubble}>
              <div className={styles.typingDot} />
              <div className={styles.typingDot} />
              <div className={styles.typingDot} />
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className={styles.inputArea}>
        <div className={styles.inputBox}>
          <textarea
            ref={inputRef}
            className={styles.input}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKey}
            placeholder={language?.placeholder || 'Ask anything about your deen...'}
            dir={isRTL ? 'rtl' : 'ltr'}
            rows={1}
            onInput={e => {
              e.target.style.height = 'auto'
              e.target.style.height = Math.min(e.target.scrollHeight, 100) + 'px'
            }}
          />
          <button
            className={styles.sendBtn}
            onClick={() => sendMessage()}
            disabled={!input.trim() || typing}
          >
            <svg viewBox="0 0 24 24" fill="currentColor">
              <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
            </svg>
          </button>
        </div>
      </div>
    </div>
  )
}

function formatText(text) {
  return text
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    .replace(/\n\n/g, '<br/><br/>')
    .replace(/\n/g, '<br/>')
}

function hasQuranRef(text) {
  return /quran|surah|سورة|hadith|bukhari|muslim/i.test(text)
}
