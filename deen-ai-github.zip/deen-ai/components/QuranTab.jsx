// components/QuranTab.jsx
'use client'
import { useState } from 'react'
import { SURAHS, searchSurahs } from '@/lib/quran'
import styles from './QuranTab.module.css'

export default function QuranTab({ language, onAskAbout }) {
  const [query, setQuery] = useState('')
  const filtered = searchSurahs(query)

  return (
    <div className={styles.tab}>
      <div className={styles.header}>
        <div className={styles.arabic}>القرآن الكريم</div>
        <div className={styles.sub}>The Holy Quran — Search & Guidance</div>
      </div>

      <div className={styles.search}>
        <span>🔍</span>
        <input
          type="text"
          placeholder="Search surah or topic..."
          value={query}
          onChange={e => setQuery(e.target.value)}
          className={styles.searchInput}
        />
        {query && (
          <span className={styles.clear} onClick={() => setQuery('')}>✕</span>
        )}
      </div>

      <div className={styles.list}>
        {filtered.map(s => (
          <div
            key={s.n}
            className={styles.card}
            onClick={() => onAskAbout(`Tell me about Surah ${s.name} and its key lessons`)}
          >
            <div className={styles.num}>{s.n}</div>
            <div className={styles.info}>
              <div className={styles.name}>{s.name}</div>
              <div className={styles.meta}>{s.verses} verses • {s.type}</div>
            </div>
            <div className={styles.arabicName}>{s.arabic}</div>
          </div>
        ))}
      </div>
    </div>
  )
}
