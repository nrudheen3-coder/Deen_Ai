// components/MainApp.jsx
'use client'
import { useState } from 'react'
import ChatTab from './ChatTab'
import QuranTab from './QuranTab'
import TopicsTab from './TopicsTab'
import SavedTab from './SavedTab'
import styles from './MainApp.module.css'

const TABS = [
  { id: 'chat',   icon: '💬', label: 'Chat'   },
  { id: 'quran',  icon: '📖', label: 'Quran'  },
  { id: 'topics', icon: '🌿', label: 'Topics' },
  { id: 'saved',  icon: '🔖', label: 'Saved'  },
]

export default function MainApp({ language, onChangeLanguage }) {
  const [activeTab, setActiveTab] = useState('chat')
  const [chatTopic, setChatTopic] = useState(null)

  function openTopicInChat(topic) {
    setChatTopic(topic)
    setActiveTab('chat')
  }

  return (
    <div className={styles.app}>
      {/* Top Bar */}
      <div className={styles.topbar}>
        <div className={styles.brand}>
          <div className={styles.logo}>د</div>
          <div className={styles.brandText}>
            <h1 className={styles.brandName}>Deen AI</h1>
            <span className={styles.langBadge} onClick={onChangeLanguage}>
              {language.flag} {language.name}
            </span>
          </div>
        </div>
        <div className={styles.actions}>
          <button className={styles.actionBtn} onClick={onChangeLanguage} title="Change Language">
            🌐
          </button>
        </div>
      </div>

      {/* Tab Content */}
      <div className={styles.content}>
        <div className={activeTab === 'chat'   ? styles.tabActive : styles.tabHidden}>
          <ChatTab language={language} initialTopic={chatTopic} />
        </div>
        <div className={activeTab === 'quran'  ? styles.tabActive : styles.tabHidden}>
          <QuranTab language={language} onAskAbout={openTopicInChat} />
        </div>
        <div className={activeTab === 'topics' ? styles.tabActive : styles.tabHidden}>
          <TopicsTab language={language} onOpenTopic={openTopicInChat} />
        </div>
        <div className={activeTab === 'saved'  ? styles.tabActive : styles.tabHidden}>
          <SavedTab language={language} />
        </div>
      </div>

      {/* Bottom Nav */}
      <nav className={styles.bottomNav}>
        {TABS.map(tab => (
          <button
            key={tab.id}
            className={`${styles.navItem} ${activeTab === tab.id ? styles.navActive : ''}`}
            onClick={() => setActiveTab(tab.id)}
          >
            <div className={styles.navDot} />
            <span className={styles.navIcon}>{tab.icon}</span>
            <span className={styles.navLabel}>{tab.label}</span>
          </button>
        ))}
      </nav>
    </div>
  )
}
