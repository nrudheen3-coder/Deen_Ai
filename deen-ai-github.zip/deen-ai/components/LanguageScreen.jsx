// components/LanguageScreen.jsx
'use client'
import { LANGUAGES } from '@/lib/language'
import styles from './LanguageScreen.module.css'

export default function LanguageScreen({ onSelect }) {
  return (
    <div className={styles.screen}>
      <div className={styles.header}>
        <span className={styles.moonIcon}>🌙</span>
        <h2 className={styles.title}>Choose Your Language</h2>
        <p className={styles.sub}>Select your preferred language to continue</p>
      </div>

      <div className={styles.grid}>
        {LANGUAGES.map(lang => (
          <div
            key={lang.code}
            className={styles.card}
            onClick={() => onSelect(lang)}
          >
            <div className={styles.flag}>{lang.flag}</div>
            <div className={styles.info}>
              <span className={styles.name}>{lang.name}</span>
              <span className={styles.native}>{lang.native}</span>
            </div>
            <div className={styles.arrow}>›</div>
          </div>
        ))}
      </div>

      <div className={styles.footer}>
        <span>بسم الله الرحمن الرحيم</span>
      </div>
    </div>
  )
}
