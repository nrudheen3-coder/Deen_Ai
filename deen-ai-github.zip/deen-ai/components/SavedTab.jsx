// components/SavedTab.jsx
'use client'
import styles from './SavedTab.module.css'

export default function SavedTab({ language }) {
  return (
    <div className={styles.tab}>
      <div className={styles.header}>
        <div className={styles.title}>Saved Guidance</div>
        <div className={styles.sub}>Your bookmarked answers</div>
      </div>
      <div className={styles.empty}>
        <div className={styles.emptyIcon}>🔖</div>
        <div className={styles.emptyText}>
          No saved guidance yet.<br/>
          Long press any answer to save it.
        </div>
      </div>
    </div>
  )
}
