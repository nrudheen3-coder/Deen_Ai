// components/TopicsTab.jsx
'use client'
import styles from './TopicsTab.module.css'

const TOPICS = [
  { id: 'daily',    icon: '🌿', name: 'Daily Life',       desc: 'Prayers, fasting, everyday Islamic practice' },
  { id: 'quran',    icon: '📖', name: 'Quran & Hadith',   desc: 'Verses, meaning and authentic hadith'         },
  { id: 'family',   icon: '💑', name: 'Marriage & Family',desc: 'Relationships, parenting, nikah guidance'     },
  { id: 'business', icon: '💼', name: 'Halal Business',   desc: 'Islamic finance, trading, work ethics'        },
  { id: 'mental',   icon: '🤲', name: 'Mental Health',    desc: 'Peace, anxiety, depression — Islamic lens'    },
  { id: 'dua',      icon: '✨', name: 'Duas & Dhikr',     desc: 'Supplications for every occasion'             },
]

export default function TopicsTab({ language, onOpenTopic }) {
  return (
    <div className={styles.tab}>
      <div className={styles.header}>
        <div className={styles.title}>Islamic Guidance</div>
        <div className={styles.sub}>Choose a topic for focused guidance</div>
      </div>

      <div className={styles.grid}>
        {TOPICS.map(t => (
          <div
            key={t.id}
            className={styles.card}
            onClick={() => onOpenTopic(t.id)}
          >
            <span className={styles.icon}>{t.icon}</span>
            <div className={styles.name}>{t.name}</div>
            <div className={styles.desc}>{t.desc}</div>
          </div>
        ))}
      </div>

      <div className={styles.bismillah}>بسم الله الرحمن الرحيم</div>
    </div>
  )
}
