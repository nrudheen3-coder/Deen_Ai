<div align="center">

# 🌙 Deen AI — دين
### Free Islamic Life Companion

> **Built by Muslims. For Muslims. Free Forever.**

![Version](https://img.shields.io/badge/version-1.0.0-green)
![License](https://img.shields.io/badge/license-MIT-gold)
![Next.js](https://img.shields.io/badge/Next.js-14-black)
![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen)

**Tamil • English • Urdu • Arabic • Malay**

</div>

---

## 🤲 Our Mission

Every Muslim deserves free Islamic guidance — in their own language — anytime — anywhere.

While everyone else charges for AI, Deen AI is and will always be **completely free**.

---

## ✨ Features

| Feature | Status |
|---|---|
| 💬 Conversational Islamic AI guidance | ✅ Live |
| 📖 Quran & Hadith references | ✅ Live |
| 💑 Marriage & family guidance | ✅ Live |
| 💼 Halal business advice | ✅ Live |
| 🧠 Mental health — Islamic lens | ✅ Live |
| ✨ Duas & Dhikr guidance | ✅ Live |
| 🌍 5 Languages (Tamil, English, Urdu, Arabic, Malay) | ✅ Live |
| 📱 PWA — installable on any device | ✅ Live |
| 🔄 Auto language detection | ✅ Live |
| ↔️ RTL support for Arabic & Urdu | ✅ Live |
| 🆓 Forever free — no ads, no paywalls | ✅ Always |

---

## 🛠️ Tech Stack

- **Frontend**: Next.js 14, React, CSS Modules
- **AI**: OpenRouter (Free models — Llama, Mistral)
- **Styling**: Custom Islamic design system (Green + Gold)
- **PWA**: Web manifest, offline-ready
- **Hosting**: Vercel (free tier)
- **Database**: Firebase (coming soon)

**Total monthly cost: ₹0** 🎯

---

## 🚀 Quick Start

### 1. Clone the repo
```bash
git clone https://github.com/YOUR_USERNAME/deen-ai.git
cd deen-ai
```

### 2. Install dependencies
```bash
npm install
```

### 3. Setup environment
```bash
cp .env.example .env.local
```

Edit `.env.local` and add your **free** OpenRouter API key:
```
OPENROUTER_API_KEY=sk-or-your-key-here
```

Get your FREE key at [openrouter.ai](https://openrouter.ai) — no credit card needed!

### 4. Run locally
```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) 🌙

---

## 🌍 Deploy to Vercel (Free)

```bash
npm install -g vercel
vercel
```

Add your `OPENROUTER_API_KEY` in Vercel dashboard → Settings → Environment Variables.

---

## 🤝 How To Contribute

We welcome **every Muslim** who wants to help — coder or not!

### We need:
- 💻 **Developers** — React, Next.js features
- 🌍 **Translators** — Add more Muslim languages
- 📖 **Islamic advisors** — Review AI responses for accuracy
- 🎨 **Designers** — UI/UX improvements
- 🧪 **Testers** — Find bugs, report issues
- 📝 **Writers** — Documentation, Islamic content

### To contribute:
1. Fork the repository
2. Create your branch: `git checkout -b feature/your-feature`
3. Commit changes: `git commit -m 'Add: your feature'`
4. Push: `git push origin feature/your-feature`
5. Open a Pull Request

See [CONTRIBUTING.md](CONTRIBUTING.md) for detailed guidelines.

---

## 🗺️ Roadmap

- [ ] Firebase authentication & saved conversations
- [ ] More languages (Bengali, Turkish, Indonesian, Hausa)
- [ ] Prayer times integration
- [ ] Quran audio recitation
- [ ] Hadith search engine
- [ ] Islamic calendar
- [ ] Community Q&A
- [ ] Scholar verification badge for answers
- [ ] Offline mode

---

## 💎 Sadaqah Jariyah

> *"When a person dies, all their deeds end except three — ongoing charity, knowledge others benefit from, or a righteous child who prays for them."*
> — Prophet Muhammad ﷺ

Every contribution to Deen AI is **Sadaqah Jariyah** — ongoing reward that continues after we're gone. 🤲

---

## 📄 License

MIT License — free to use, modify, and distribute.

---

## 🌙 Made With Love

Built by a Muslim developer, for the global Muslim Ummah.

> *"And whoever saves one life — it is as if he has saved all of mankind."*
> — Quran 5:32

**Bismillah — let's serve the Ummah together.** 🤲

